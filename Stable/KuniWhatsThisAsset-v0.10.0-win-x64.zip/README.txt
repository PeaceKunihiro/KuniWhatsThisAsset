KuniWhatsThisAsset v0.10.0 / Windows x64

KuniWhatsThisAsset.App.exeを起動してください。フォルダーの内容は一式で保持してください。
.NET 10は同梱されています。
モデル解析にはMicrosoft Visual C++ v14 x64ランタイムが必要です。
Microsoft公式インストーラー: https://aka.ms/vc14/vc_redist.x64.exe

.unitypackageを開き、ツリーから画像・FBX・OBJ・Prefabを選択してプレビューします。
モデル: 左ドラッグで回転、右/中ドラッグで移動、ホイールでズーム。
100,000三角形以上、または依存マテリアル10以上は描画前に確認します。
Prefabは元モデルの初期形状による近似表示です。入れ子/Variantの材質スロット・表示状態の差分に対応します。配置変更・Bone姿勢・BlendShape・追加/削除Component・Unity専用Shaderの完全再現には未対応です。

初回描画後、正面/側面/平面の透過PNGを保持します。再表示は写真を使用し、3D表示ボタンで再描画します。
Setting→読み込み設定でパッケージ容量・キャッシュ容量（各初期500 MiB）の変更/無制限化ができます。
アドレスバーのクリックで直近10件の履歴を表示します。
★シングルクリックで現在のフォルダーを登録、ダブルクリックで削除、右クリックで一覧を表示します。

設定: %LOCALAPPDATA%/KuniWhatsThisAsset/preferences.json
キャッシュ: %LOCALAPPDATA%/KuniWhatsThisAsset/RenderCache/
Help→ライセンス、およびlicenses/で依存コンポーネントのライセンスを確認できます。
検出なしはパッケージの安全性を保証しません。
ユーザー提供テストデータと検証画像は本ZIPに含みません。

詳細: https://github.com/PeaceKunihiro/KuniWhatsThisAsset


v0.9.1修正：
- FBX/Prefabの材質探索を共通化し、親階層Materialsとモデルmetaの検索・命名設定に対応。
- 名前が異なる材質はPrefabのMesh/材質スロットから一意の場合に補完。
- 競合する材質・Prefab差分の変更は推定せず、未解決理由をプレビューへ表示。
- 描画キャッシュを更新し、旧版で作られた単色写真を再利用せず再生成。
- Akyo PC/Questと5000ポリネコメイドのFBX・Prefab計6経路で自動テクスチャ表示を検証。


v0.10.0修正：
- モデル/画像のエラー、参照注記、キャッシュ保存失敗の詳細を既存警告欄へ統合。
- プレビューは統計と操作案内のみ。キャッシュ注記も警告欄へ復元し、文字で画面を覆わない。
- パッケージ解析の警告は保持し、選択アセットの診断だけ更新。警告欄は自動展開しない。
- 旧キャッシュも含む、同じ原因の二次的な参照エラーを重複表示しない。
- FUWATTO v26を調査。参照エラーは414Prefabに対する32件補完上限と、未対応の材質差分等が主因。
- 今回の参照関連は調査までで、探索上限/Prefab差分の仕様は変更しない。

参照処理: 選択Prefabの依存関係だけを解析し、Unityの対象IDに一致した材質を適用します。Material/MatフォルダーとUnicodeエスケープ名にも対応します。
対応しないIDは警告欄で確認できます。従来の描画キャッシュは再生成されます。
System.IO.Hashing 10.0.0のMITライセンス・第三者通知はHelp→ライセンスおよびlicenses/で確認できます。
