KuniWhatsThisAsset v0.8.0 / Windows x64

KuniWhatsThisAsset.App.exeを起動してください。フォルダーの内容は一式で保持してください。
.NET 10は同梱されています。
モデルプレビューにはMicrosoft Visual C++ v14 x64ランタイムが必要です。
Microsoft公式インストーラー: https://aka.ms/vc14/vc_redist.x64.exe

.unitypackageを開き、ツリーから画像・FBX・OBJを選択してプレビューします。
モデル: 左ドラッグで回転、右/中ドラッグで移動、ホイールでズーム。
100,000三角形以上、または依存マテリアル10以上は描画前に確認します。
Unity専用Shader・Prefab設定・アニメーション・商品画像のポーズの完全再現には未対応です。

Help→ライセンス、およびlicenses/で依存コンポーネントのライセンスを確認できます。
検出なしはパッケージの安全性を保証しません。
モデル・テクスチャ等のユーザー提供テストデータは本ZIPに含みません。

詳細: https://github.com/PeaceKunihiro/KuniWhatsThisAsset
