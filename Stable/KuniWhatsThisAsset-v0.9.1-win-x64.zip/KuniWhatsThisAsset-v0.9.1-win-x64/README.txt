KuniWhatsThisAsset v0.9.1 / Windows x64

KuniWhatsThisAsset.App.exeを起動してください。フォルダーの内容は一式で保持してください。
.NET 10は同梱されています。
モデル解析にはMicrosoft Visual C++ v14 x64ランタイムが必要です。
Microsoft公式インストーラー: https://aka.ms/vc14/vc_redist.x64.exe

.unitypackageを開き、ツリーから画像・FBX・OBJ・Prefabを選択してプレビューします。
モデル: 左ドラッグで回転、右/中ドラッグで移動、ホイールでズーム。
100,000三角形以上、または依存マテリアル10以上は描画前に確認します。
Prefabは元モデルの初期形状による近似表示です。配置変更・Bone姿勢・BlendShape・FBXインスタンス差分・Unity専用Shaderの完全再現には未対応です。

初回描画後、正面/側面/平面の透過PNGを保持します。再表示は写真を使用し、3D表示ボタンで再描画します。
Setting→読み込み設定でパッケージ容量・キャッシュ容量（各初期500 MiB）の変更/無制限化ができます。
アドレスバーのクリックで直近10件の履歴を表示します。
★シングルクリックで現在のフォルダーを登録、ダブルクリックで削除、右クリックで一覧を表示します。

設定: %LOCALAPPDATA%/KuniWhatsThisAsset/preferences.json
キャッシュ: %LOCALAPPDATA%/KuniWhatsThisAsset/RenderCache/
Help→ライセンス、およびlicenses/で依存コンポーネントのライセンスを確認できます。
検出なしはパッケージの安全性を保証しません。
ユーザー提供テストデータと検証画像は本ZIPに含みません。

詳細: https://github.com/PeaceKunihiro/KuniWhatsThisAsset


v0.9.1修正：
- FBX/Prefabの材質探索を共通化し、親階層Materialsとモデルmetaの検索・命名設定に対応。
- 名前が異なる材質はPrefabのMesh/材質スロットから一意の場合に補完。
- 競合する材質・Prefab差分の変更は推定せず、未解決理由をプレビューへ表示。
- 描画キャッシュを更新し、旧版で作られた単色写真を再利用せず再生成。
- Akyo PC/Questと5000ポリネコメイドのFBX・Prefab計6経路で自動テクスチャ表示を検証。
