KuniWhatsThisAsset v0.5.0 — 初回実装版
Copyright (c) 2026 KuniWhatsThisAsset contributors

KuniWhatsThisAsset.App.exe を起動し、.unitypackageを開いてください。
.NETの別途インストールは不要です。このフォルダーの全ファイルを保持してください。

対応: 内容物一覧、検索、静的ルールによる危険要素検出、UTF-8/UTF-16/Shift-JISテキストプレビュー、PNG/JPEG/BMP/GIF/TIFF/ICO画像プレビュー。
モデルプレビューは未対応です。未検出は安全性の保証ではありません。
実際のUnityエクスポートを使った広範な互換性検証は未実施です。

本プロジェクトの公開ライセンスは未定です。この成果物はローカル検証用です。
同梱ランタイムには licenses/ のライセンスと第三者通知が適用されます。




